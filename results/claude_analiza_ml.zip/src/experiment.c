

 #include "experiment.h"

#include "adaptive_imputation.h"
#include "interpolation.h"
#include "knn_methods.h"
#include "knn_upgraded.h"
#include "decision_tree.h"
#include "rf_methods.h"
#include "preprocessing.h"

#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include <direct.h>
#else
#include <sys/stat.h>
#endif

#define DEMO_CSV "data/raw/temperature_demo_cities.csv"
#define PROCESSED_CSV "data/processed/jena_temperature_7d.csv"
#define DEFAULT_CITY "Split"
#define RANDOM_SEED 42ULL

static const double EXP_MISSING_RATES[] = {0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80};
static const size_t EXP_NUM_RATES = sizeof(EXP_MISSING_RATES) / sizeof(EXP_MISSING_RATES[0]);

static const ExpScenario EXP_ALL_SCENARIOS[] = {
    EXP_SCENARIO_RANDOM,
    EXP_SCENARIO_BLOCK,
    EXP_SCENARIO_BLOCK_START,
    EXP_SCENARIO_BLOCK_MIDDLE,
    EXP_SCENARIO_BLOCK_END,
};

typedef struct {
    ExpScenario scenario;
    double rate;
    size_t removed;
    const char *best_method;
    double best_mae;
    int has_best;
} ExpRunSummary;

static const char *exp_scenario_description(ExpScenario scenario) {
    switch (scenario) {
    case EXP_SCENARIO_RANDOM:
        return "Nasumicno uklanjamo pojedinacne temperature (pojedinacne rupe u nizu).";
    case EXP_SCENARIO_BLOCK:
        return "Uklanjamo jedan kontinuirani blok na nasumicnoj poziciji (kvar senzora).";
    case EXP_SCENARIO_BLOCK_START:
        return "Uklanjamo jedan blok na POCETKU niza (prva vrijednost ostaje).";
    case EXP_SCENARIO_BLOCK_MIDDLE:
        return "Uklanjamo jedan blok u SREDINI niza.";
    case EXP_SCENARIO_BLOCK_END:
        return "Uklanjamo jedan blok na KRAJU niza (zadnja vrijednost ostaje).";
    default:
        return "";
    }
}

static void find_best_method(const ExpMethodResult *results, size_t n,
                             const char **best_name, double *best_mae) {
    *best_name = NULL;
    *best_mae = INFINITY;
    for (size_t i = 0; i < n; i++) {
        if (!results[i].ok) {
            continue;
        }
        if (results[i].metrics.mae < *best_mae) {
            *best_mae = results[i].metrics.mae;
            *best_name = results[i].name;
        }
    }
}

static void find_worst_method(const ExpMethodResult *results, size_t n,
                              const char **worst_name, double *worst_mae) {
    *worst_name = NULL;
    *worst_mae = -INFINITY;
    for (size_t i = 0; i < n; i++) {
        if (!results[i].ok) {
            continue;
        }
        if (results[i].metrics.mae > *worst_mae) {
            *worst_mae = results[i].metrics.mae;
            *worst_name = results[i].name;
        }
    }
}

static void print_methods_table(const ExpMethodResult *results, size_t n) {
    printf("\n");
    printf("  #  %-24s %8s %8s %8s  %s\n",
           "metoda", "MAE", "RMSE", "R2", "sto znaci");
    printf("  -- %-24s %8s %8s %8s  %s\n",
           "------------------------", "------", "------", "------", "-------------------------");

    const char *best_name = NULL;
    const char *worst_name = NULL;
    double best_mae = INFINITY;
    double worst_mae = -INFINITY;
    find_best_method(results, n, &best_name, &best_mae);
    find_worst_method(results, n, &worst_name, &worst_mae);

    int rank = 0;
    for (size_t i = 0; i < n; i++) {
        if (!results[i].ok) {
            printf("  -  %-24s  %s\n", results[i].name,
                   "[preskoceno - premalo poznatih tocaka]");
            continue;
        }
        rank++;
        const char *marker = "";
        if (results[i].name == best_name) {
            marker = " <-- NAJBOLJA";
        } else if (results[i].name == worst_name) {
            marker = " <-- NAJGORA";
        }
        const char *r2_hint = "";
        if (results[i].metrics.r2 >= 0.99) {
            r2_hint = "odlicno";
        } else if (results[i].metrics.r2 >= 0.90) {
            r2_hint = "dobro";
        } else if (results[i].metrics.r2 >= 0.0) {
            r2_hint = "slabo";
        } else {
            r2_hint = "losije od srednje";
        }

        printf("  %d  %-24s %8.4f %8.4f %8.4f  %s%s\n",
               rank, results[i].name,
               results[i].metrics.mae, results[i].metrics.rmse,
               results[i].metrics.r2, r2_hint, marker);
    }

    if (best_name) {
        printf("\n  >> Najbolja metoda: %s (MAE = %.4f C)\n",
               best_name, best_mae);
    }
    if (worst_name && worst_name != best_name) {
        printf("  >> Najgora metoda:  %s (MAE = %.4f C)\n",
               worst_name, worst_mae);
    }
}

static void print_run_block_header(ExpScenario scenario, double rate,
                                   size_t removed, size_t n) {
    printf("\n");
    printf("----------------------------------------------------------------------\n");
    printf("TEST: %s", exp_scenario_name(scenario));
    if (strcmp(exp_block_position_name(scenario), "none") != 0) {
        printf("  [pozicija bloka: %s]", exp_block_position_name(scenario));
    }
    printf("  |  missing rate: %.0f%%\n", rate * 100.0);
    printf("----------------------------------------------------------------------\n");
    printf("Opis: %s\n", exp_scenario_description(scenario));
    printf("Uklonjeno: %zu od %zu vrijednosti (evaluacija samo na tim mjestima)\n",
           removed, n);
}

static void print_experiment_intro(const char *source, const char *label_city,
                                   size_t n, const ExpRunFilter *filter) {
    printf("\n");
    printf("======================================================================\n");
    printf("  EKSPERIMENT — IMPUTACIJA NEDOSTAJUCIH TEMPERATURA\n");
    printf("======================================================================\n\n");
    printf("STO SE DOGADA:\n");
    printf("  1. Ucitavamo originalni temperaturni niz (bez mijenjanja)\n");
    printf("  2. Umjetno uklanjamo vrijednosti prema scenariju (maska = 1)\n");
    printf("  3. Svaka od %d metoda popunjava isti osteceni niz\n", EXP_NUM_METHODS);
    printf("  4. Usporedujemo rekonstrukciju s originalom SAMO na uklonjenim mjestima\n\n");
    printf("PODACI:\n");
    printf("  Izvor:            %s\n", source);
    if (label_city) {
        printf("  Grad:             %s\n", label_city);
    }
    printf("  Broj zapisa:      %zu (10-min intervali)\n", n);
    printf("  Scenariji:        5 (random, block, block_start, block_middle, block_end)\n");
    printf("  Missing rateovi:  10%%, 20%%, 30%%, 40%%, 50%%, 60%%, 70%%, 80%%\n");
    printf("  Metode:           8 (klasicne + ML)\n");
    if (filter && (filter->has_scenario || filter->has_rate)) {
        printf("  Filter:           ");
        if (filter->has_scenario) {
            printf("scenarij=%s ", exp_scenario_name(filter->scenario));
        }
        if (filter->has_rate) {
            printf("rate=%.0f%% ", filter->missing_rate * 100.0);
        }
        printf("\n");
    }
    printf("\nMETRIKE (nizi = bolje, osim R2):\n");
    printf("  MAE  — prosjecna apsolutna pogreska u stupnjevima Celsijusa\n");
    printf("  RMSE — korijen prosjecne kvadratne pogreske (kaznjava velike greske)\n");
    printf("  R2   — 1.0 = savrseno; 0 = kao srednja vrijednost; negativno = lose\n");
}

static void print_experiment_footer(const char *results_dir,
                                    const char *main_csv, const char *mae_csv,
                                    const char *error_csv,
                                    const ExpRunSummary *summary, size_t summary_count,
                                    size_t total_runs, size_t n) {
    printf("\n");
    printf("======================================================================\n");
    printf("  SAZETAK EKSPERIMENTA\n");
    printf("======================================================================\n\n");
    printf("Ukupno pokrenuto: %zu kombinacija (scenarij x rate x metoda = %zu testova)\n",
           summary_count, total_runs);

    if (summary_count > 0) {
        printf("\nNAJBOLJA METODA PO SCENARIJU I MISSING RATEU (prema MAE):\n\n");
        printf("  %-14s %6s  %-12s  %8s  %s\n",
               "scenarij", "rate", "pozicija", "MAE", "metoda");
        printf("  %-14s %6s  %-12s  %8s  %s\n",
               "--------------", "------", "------------", "--------", "--------------------");

        for (size_t i = 0; i < summary_count; i++) {
            if (!summary[i].has_best) {
                continue;
            }
            printf("  %-14s %5.0f%%  %-12s  %8.4f  %s\n",
                   exp_scenario_name(summary[i].scenario),
                   summary[i].rate * 100.0,
                   exp_block_position_name(summary[i].scenario),
                   summary[i].best_mae,
                   summary[i].best_method);
        }
    }

    printf("\n");
    printf("GDJE SU REZULTATI:\n\n");
    printf("  %s\n", main_csv);
    printf("    -> glavna tablica za diplomski rad (sve metrike)\n\n");
    printf("  %s\n", mae_csv);
    printf("    -> MAE po metodi (za brze usporedbe)\n\n");
    printf("  %s\n", error_csv);
    printf("    -> MAE/RMSE/R2 po scenariju i rateu\n\n");
    printf("  %s/reconstruction_{metoda}_{scenario}_0.20.csv\n", results_dir);
    printf("    -> original vs rekonstruirano (najbolja i najgora metoda, pri 20%%)\n\n");
    printf("  %s/reconstruction_best_worst_20.csv\n", results_dir);
    printf("    -> pregled najbolje i najgore metode po scenariju (20%%)\n\n");

    printf("KAKO KORISTITI ZA DIPLOMSKI:\n");
    printf("  - Otvori experiment_results.csv u Excelu\n");
    printf("  - Filtriraj po 'scenario' i 'missing_rate'\n");
    printf("  - Sortiraj po 'mae' za rang metoda\n");
    printf("  - Za grafove pokreni: python scripts/report.py\n\n");

    printf("BRZI ZAKLJUCAK IZ REZULTATA:\n");
    printf("  - Random missing: klasicne metode (spline/linear) obicno najbolje\n");
    printf("  - Block missing: linear/time obicno najbolje; KNN cesto lose\n");
    printf("  - Pozicija bloka (start/middle/end) utjece na tezinu imputacije\n");
    printf("  - Visi missing rate (do 80%%) -> veca pogreska kod svih metoda\n");
    printf("  - Pri 80%% block scenarij uklanja do %zu vrijednosti (prva i zadnja ostaju)\n\n",
           (size_t)llround(0.80 * (double)n));
    printf("======================================================================\n\n");
}

/* Missing rate pri kojem se automatski sprema reconstruction CSV u --experiment. */
#define EXP_RECON_SNAPSHOT_RATE 0.20

typedef int (*ExpApplyFn)(const Series *s, const double *damaged, size_t n, double *out);

typedef struct {
    const char *name;
    ExpApplyFn apply;
} ExpMethodEntry;

static int apply_forward_fill(const Series *s, const double *damaged, size_t n, double *out) {
    (void)s;
    forward_fill(damaged, n, out);
    return 0;
}

static int apply_linear(const Series *s, const double *damaged, size_t n, double *out) {
    (void)s;
    linear_interpolation(damaged, n, out);
    return 0;
}

static int apply_time(const Series *s, const double *damaged, size_t n, double *out) {
    time_interpolation(damaged, n, s->epoch, out);
    return 0;
}

static int apply_cubic(const Series *s, const double *damaged, size_t n, double *out) {
    (void)s;
    return cubic_interpolation(damaged, n, out);
}

static int apply_spline(const Series *s, const double *damaged, size_t n, double *out) {
    (void)s;
    return spline_interpolation(damaged, n, out);
}

static int apply_moving_average(const Series *s, const double *damaged, size_t n, double *out) {
    (void)s;
    moving_average_imputation(damaged, n, MOVING_AVERAGE_DEFAULT_WINDOW, out);
    return 0;
}

static int apply_knn(const Series *s, const double *damaged, size_t n, double *out) {
    (void)n;
    return knn_imputation(s, damaged, 5, out);
}

static int apply_knn_upgraded(const Series *s, const double *damaged, size_t n, double *out) {
    (void)n;
    return knn_imputation_upgraded(s, damaged, NULL, out);
}

static int apply_decision_tree(const Series *s, const double *damaged, size_t n, double *out) {
    (void)n;
    return decision_tree_imputation(s, damaged, out);
}

static int apply_random_forest(const Series *s, const double *damaged, size_t n, double *out) {
    (void)n;
    return rf_imputation(s, damaged, out);
}

static int apply_adaptive(const Series *s, const double *damaged, size_t n, double *out) {
    (void)s;
    (void)damaged;
    (void)n;
    (void)out;
    fprintf(stderr, "adaptive_imputation zahtijeva masku; koristi exp_run_methods.\n");
    return 1;
}

static const ExpMethodEntry EXP_METHOD_TABLE[] = {
    {"forward_fill", apply_forward_fill},
    {"linear_interpolation", apply_linear},
    {"time_interpolation", apply_time},
    {"cubic_interpolation", apply_cubic},
    {"spline_interpolation", apply_spline},
    {"moving_average", apply_moving_average},
    {"knn", apply_knn},
    {"knn_upgraded", apply_knn_upgraded},
    {"decision_tree", apply_decision_tree},
    {"random_forest", apply_random_forest},
    {"adaptive_imputation", apply_adaptive},
};

static const size_t EXP_METHOD_TABLE_SIZE =
    sizeof(EXP_METHOD_TABLE) / sizeof(EXP_METHOD_TABLE[0]);

const char *exp_scenario_name(ExpScenario scenario) {
    switch (scenario) {
    case EXP_SCENARIO_BLOCK:
        return "block";
    case EXP_SCENARIO_BLOCK_START:
        return "block_start";
    case EXP_SCENARIO_BLOCK_MIDDLE:
        return "block_middle";
    case EXP_SCENARIO_BLOCK_END:
        return "block_end";
    case EXP_SCENARIO_RANDOM:
    default:
        return "random";
    }
}

const char *exp_block_position_name(ExpScenario scenario) {
    switch (scenario) {
    case EXP_SCENARIO_BLOCK_START:
        return "start";
    case EXP_SCENARIO_BLOCK_MIDDLE:
        return "middle";
    case EXP_SCENARIO_BLOCK_END:
        return "end";
    default:
        return "none";
    }
}

int exp_scenario_from_string(const char *text, ExpScenario *out) {
    if (!text || !out) {
        return -1;
    }
    if (strcmp(text, "random") == 0) {
        *out = EXP_SCENARIO_RANDOM;
        return 0;
    }
    if (strcmp(text, "block") == 0) {
        *out = EXP_SCENARIO_BLOCK;
        return 0;
    }
    if (strcmp(text, "block_start") == 0) {
        *out = EXP_SCENARIO_BLOCK_START;
        return 0;
    }
    if (strcmp(text, "block_middle") == 0) {
        *out = EXP_SCENARIO_BLOCK_MIDDLE;
        return 0;
    }
    if (strcmp(text, "block_end") == 0) {
        *out = EXP_SCENARIO_BLOCK_END;
        return 0;
    }
    return -1;
}

size_t exp_create_damage(ExpScenario scenario, const double *temp, size_t n,
                         double missing_rate, unsigned long long seed,
                         double *damaged, int *mask) {
    switch (scenario) {
    case EXP_SCENARIO_BLOCK:
        return create_single_block_missing_values(temp, n, missing_rate, seed,
                                                  PREPROC_BLOCK_POS_RANDOM,
                                                  damaged, mask);
    case EXP_SCENARIO_BLOCK_START:
        return create_single_block_missing_values(temp, n, missing_rate, seed,
                                                  PREPROC_BLOCK_POS_START,
                                                  damaged, mask);
    case EXP_SCENARIO_BLOCK_MIDDLE:
        return create_single_block_missing_values(temp, n, missing_rate, seed,
                                                  PREPROC_BLOCK_POS_MIDDLE,
                                                  damaged, mask);
    case EXP_SCENARIO_BLOCK_END:
        return create_single_block_missing_values(temp, n, missing_rate, seed,
                                                  PREPROC_BLOCK_POS_END,
                                                  damaged, mask);
    case EXP_SCENARIO_RANDOM:
    default:
        return create_missing_values(temp, n, missing_rate, seed, damaged, mask);
    }
}

static int ensure_results_dir(const char *path) {
#ifdef _WIN32
    if (_mkdir(path) == 0) {
        return 0;
    }
#else
    if (mkdir(path, 0755) == 0) {
        return 0;
    }
#endif
    return (errno == EEXIST) ? 0 : -1;
}

static int load_series(const char *source, const char *city, Series *s,
                       const char **label_city) {
    const char *path;
    const char *city_filter = NULL;

    if (strcmp(source, "demo") == 0) {
        path = DEMO_CSV;
        city_filter = (city != NULL) ? city : DEFAULT_CITY;
        *label_city = city_filter;
    } else if (strcmp(source, "jena_quick") == 0 || strcmp(source, "processed") == 0) {
        path = PROCESSED_CSV;
        *label_city = NULL;
    } else {
        fprintf(stderr, "Nepoznat izvor: %s (koristi demo | jena_quick | processed)\n", source);
        return 1;
    }

    if (series_load_csv(s, path, city_filter) != 0) {
        return 1;
    }
    return 0;
}

static const ExpMethodEntry *find_method(const char *name) {
    for (size_t i = 0; i < EXP_METHOD_TABLE_SIZE; i++) {
        if (strcmp(EXP_METHOD_TABLE[i].name, name) == 0) {
            return &EXP_METHOD_TABLE[i];
        }
    }
    return NULL;
}

int exp_apply_method(const char *method_name, const Series *s,
                     const double *damaged, size_t n, double *out) {
    const ExpMethodEntry *entry = find_method(method_name);
    if (!entry) {
        return 1;
    }
    return entry->apply(s, damaged, n, out);
}

static int apply_method_with_mask(const char *method_name, const Series *s,
                                  const double *damaged, const int *mask,
                                  size_t n, double *out) {
    if (strcmp(method_name, "adaptive_imputation") == 0) {
        return adaptive_imputation(s, damaged, mask, n, out);
    }
    return exp_apply_method(method_name, s, damaged, n, out);
}

int exp_run_methods(const Series *s, const double *original, const double *damaged,
                    const int *mask, size_t n, double *out, ExpMethodResult *results) {
    if (!s || !original || !damaged || !mask || !out || !results) {
        return 1;
    }
    if (EXP_METHOD_TABLE_SIZE != EXP_NUM_METHODS) {
        fprintf(stderr, "Greska: tablica metoda i EXP_NUM_METHODS se ne podudaraju.\n");
        return 1;
    }

    for (size_t i = 0; i < EXP_METHOD_TABLE_SIZE; i++) {
        results[i].name = EXP_METHOD_TABLE[i].name;
        if (strcmp(EXP_METHOD_TABLE[i].name, "adaptive_imputation") == 0) {
            if (adaptive_imputation(s, damaged, mask, n, out) == 0) {
                results[i].ok = 1;
                results[i].metrics = evaluate_reconstruction(original, out, mask, n);
            } else {
                results[i].ok = 0;
                results[i].metrics = (Metrics){0};
            }
            continue;
        }
        if (EXP_METHOD_TABLE[i].apply(s, damaged, n, out) == 0) {
            results[i].ok = 1;
            results[i].metrics = evaluate_reconstruction(original, out, mask, n);
        } else {
            results[i].ok = 0;
            results[i].metrics = (Metrics){0};
        }
    }
    return 0;
}

static void write_csv_header(FILE *fp, const char *header) {
    fprintf(fp, "%s\n", header);
}

static void format_epoch_timestamp(long long epoch, char *buf, size_t buflen) {
    time_t t = (time_t)epoch;
    struct tm *tm = gmtime(&t);
    if (tm) {
        snprintf(buf, buflen, "%04d-%02d-%02d %02d:%02d:%02d",
                 tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday,
                 tm->tm_hour, tm->tm_min, tm->tm_sec);
    } else {
        snprintf(buf, buflen, "%lld", (long long)epoch);
    }
}

static int write_reconstruction_csv(const char *path, const Series *s,
                                  const double *original, const double *damaged,
                                  const double *reconstructed, const int *mask,
                                  size_t n, ExpScenario scenario,
                                  double missing_rate, const char *method_name) {
    FILE *fp = fopen(path, "w");
    if (!fp) {
        fprintf(stderr, "Ne mogu otvoriti %s za pisanje.\n", path);
        return 1;
    }

    write_csv_header(fp,
        "index,timestamp,original_temperature,damaged_temperature,"
        "reconstructed_temperature,mask,scenario,block_position,missing_rate,method");

    for (size_t i = 0; i < n; i++) {
        char ts[64];
        format_epoch_timestamp(s->epoch[i], ts, sizeof(ts));

        fprintf(fp, "%zu,%s,%.6f,", i, ts, original[i]);
        if (isnan(damaged[i])) {
            fprintf(fp, ",");
        } else {
            fprintf(fp, "%.6f,", damaged[i]);
        }
        if (isnan(reconstructed[i])) {
            fprintf(fp, ",");
        } else {
            fprintf(fp, "%.6f,", reconstructed[i]);
        }
        fprintf(fp, "%d,%s,%s,%.2f,%s\n",
                mask[i], exp_scenario_name(scenario),
                exp_block_position_name(scenario), missing_rate, method_name);
    }

    fclose(fp);
    return 0;
}

static void reconstruction_path(char *buf, size_t buflen, const char *results_dir,
                              const char *method_name, ExpScenario scenario,
                              double missing_rate) {
    snprintf(buf, buflen, "%s/reconstruction_%s_%s_%.2f.csv",
             results_dir, method_name, exp_scenario_name(scenario), missing_rate);
}

int exp_export_reconstruction(const char *results_dir, const char *method_name,
                              ExpScenario scenario, double missing_rate,
                              const Series *s, const double *original,
                              const double *damaged, const int *mask,
                              size_t n, double *out) {
    if (!results_dir || !method_name || !s || !original || !damaged || !mask || !out) {
        return 1;
    }
    if (find_method(method_name) == NULL) {
        fprintf(stderr, "Nepoznata metoda za export: %s\n", method_name);
        return 1;
    }
    if (ensure_results_dir(results_dir) != 0) {
        fprintf(stderr, "Ne mogu kreirati mapu %s\n", results_dir);
        return 1;
    }
    if (apply_method_with_mask(method_name, s, damaged, mask, n, out) != 0) {
        fprintf(stderr, "Metoda %s nije uspjela za reconstruction export.\n", method_name);
        return 1;
    }

    char path[512];
    reconstruction_path(path, sizeof(path), results_dir, method_name, scenario, missing_rate);
    return write_reconstruction_csv(path, s, original, damaged, out, mask, n,
                                  scenario, missing_rate, method_name);
}

static int append_best_worst_summary(const char *results_dir, ExpScenario scenario,
                                     double missing_rate, const char *best_name,
                                     double best_mae, const char *worst_name,
                                     double worst_mae) {
    char path[512];
    int need_header = 0;
    FILE *fp;

    snprintf(path, sizeof(path), "%s/reconstruction_best_worst_20.csv", results_dir);
    fp = fopen(path, "r");
    if (fp == NULL) {
        need_header = 1;
    } else {
        fclose(fp);
    }

    fp = fopen(path, need_header ? "w" : "a");
    if (!fp) {
        return 1;
    }
    if (need_header) {
        fprintf(fp, "scenario,block_position,missing_rate,best_method,best_mae,"
                    "worst_method,worst_mae\n");
    }
    fprintf(fp, "%s,%s,%.2f,%s,%.6f,%s,%.6f\n",
            exp_scenario_name(scenario), exp_block_position_name(scenario),
            missing_rate, best_name, best_mae, worst_name, worst_mae);
    fclose(fp);
    return 0;
}

static void export_best_worst_reconstructions(const char *results_dir, ExpScenario scenario,
                                              double missing_rate, const Series *s,
                                              const double *original, const double *damaged,
                                              const int *mask, size_t n, double *out,
                                              const ExpMethodResult *results, size_t n_results) {
    const char *best_name = NULL;
    const char *worst_name = NULL;
    double best_mae = INFINITY;
    double worst_mae = -INFINITY;
    char path[512];

    find_best_method(results, n_results, &best_name, &best_mae);
    find_worst_method(results, n_results, &worst_name, &worst_mae);

    if (!best_name || !worst_name) {
        fprintf(stderr, "  [CSV] Nema dovoljno metoda za export rekonstrukcije.\n");
        return;
    }

    printf("\n  Spremam rekonstrukcije (najbolja i najgora metoda, 20%%):\n");
    printf("    najbolja: %s (MAE = %.4f)\n", best_name, best_mae);
    printf("    najgora:  %s (MAE = %.4f)\n", worst_name, worst_mae);

    if (exp_export_reconstruction(results_dir, best_name, scenario, missing_rate,
                                    s, original, damaged, mask, n, out) == 0) {
        reconstruction_path(path, sizeof(path), results_dir, best_name, scenario, missing_rate);
        printf("  [CSV] Najbolja: %s\n", path);
    }

    if (strcmp(best_name, worst_name) != 0) {
        if (exp_export_reconstruction(results_dir, worst_name, scenario, missing_rate,
                                      s, original, damaged, mask, n, out) == 0) {
            reconstruction_path(path, sizeof(path), results_dir, worst_name, scenario,
                                missing_rate);
            printf("  [CSV] Najgora:  %s\n", path);
        }
    }

    append_best_worst_summary(results_dir, scenario, missing_rate,
                              best_name, best_mae, worst_name, worst_mae);
}

static int scenario_matches_filter(ExpScenario scenario, const ExpRunFilter *filter) {
    if (!filter || !filter->has_scenario) {
        return 1;
    }
    return scenario == filter->scenario;
}

static int rate_matches_filter(double rate, const ExpRunFilter *filter) {
    if (!filter || !filter->has_rate) {
        return 1;
    }
    return fabs(rate - filter->missing_rate) < 1e-9;
}

int exp_run_compare(const char *source, const char *city, ExpScenario scenario,
                    double missing_rate, int export_reconstruction,
                    const char *results_dir) {
    Series s = {0};
    const char *label_city = NULL;

    if (load_series(source, city, &s, &label_city) != 0) {
        return 1;
    }

    size_t n = s.n;
    double *damaged = (double *)malloc(n * sizeof(double));
    int *mask = (int *)malloc(n * sizeof(int));
    double *out = (double *)malloc(n * sizeof(double));
    ExpMethodResult results[EXP_NUM_METHODS];

    if (!damaged || !mask || !out) {
        fprintf(stderr, "Greska: nedostatak memorije.\n");
        free(damaged);
        free(mask);
        free(out);
        series_free(&s);
        return 1;
    }

    size_t removed = exp_create_damage(scenario, s.temp, n, missing_rate, RANDOM_SEED,
                                       damaged, mask);

    printf("\n");
    printf("======================================================================\n");
    printf("  USPOREDBA METODA — JEDAN TEST\n");
    printf("======================================================================\n");
    printf("Opis: %s\n", exp_scenario_description(scenario));
    printf("Izvor: %s | Zapisa: %zu | Uklonjeno: %zu (%.0f%%)\n",
           source, n, removed, missing_rate * 100.0);
    if (label_city) {
        printf("Grad: %s\n", label_city);
    }
    if (strcmp(exp_block_position_name(scenario), "none") != 0) {
        printf("Pozicija bloka: %s\n", exp_block_position_name(scenario));
    }

    exp_run_methods(&s, s.temp, damaged, mask, n, out, results);
    print_methods_table(results, EXP_NUM_METHODS);

    if (export_reconstruction && results_dir) {
        printf("\nExport reconstruction CSV:\n");
        export_best_worst_reconstructions(results_dir, scenario, missing_rate,
                                          &s, s.temp, damaged, mask, n, out,
                                          results, EXP_NUM_METHODS);
    }

    printf("\nNapomena: MAE i RMSE — nizi je bolje. R2 — blize 1.0 je bolje.\n\n");

    free(damaged);
    free(mask);
    free(out);
    series_free(&s);
    return 0;
}

int exp_run_all(const char *source, const char *city, const char *results_dir,
                const ExpRunFilter *filter) {
    Series s = {0};
    const char *label_city = NULL;

    if (load_series(source, city, &s, &label_city) != 0) {
        return 1;
    }

    if (ensure_results_dir(results_dir) != 0) {
        fprintf(stderr, "Ne mogu kreirati mapu %s\n", results_dir);
        series_free(&s);
        return 1;
    }

    size_t n = s.n;
    double *damaged = (double *)malloc(n * sizeof(double));
    int *mask = (int *)malloc(n * sizeof(int));
    double *out = (double *)malloc(n * sizeof(double));
    ExpMethodResult results[EXP_NUM_METHODS];

    if (!damaged || !mask || !out) {
        fprintf(stderr, "Greska: nedostatak memorije.\n");
        free(damaged);
        free(mask);
        free(out);
        series_free(&s);
        return 1;
    }

    char main_csv[512];
    char mae_csv[512];
    char error_csv[512];
    snprintf(main_csv, sizeof(main_csv), "%s/experiment_results.csv", results_dir);
    snprintf(mae_csv, sizeof(mae_csv), "%s/mae_by_method.csv", results_dir);
    snprintf(error_csv, sizeof(error_csv), "%s/error_vs_missing_rate.csv", results_dir);

    {
        char recon_summary[512];
        snprintf(recon_summary, sizeof(recon_summary),
                 "%s/reconstruction_best_worst_20.csv", results_dir);
        remove(recon_summary);
    }

    FILE *fp_main = fopen(main_csv, "w");
    FILE *fp_mae = fopen(mae_csv, "w");
    FILE *fp_err = fopen(error_csv, "w");
    if (!fp_main || !fp_mae || !fp_err) {
        fprintf(stderr, "Ne mogu otvoriti CSV datoteke u %s\n", results_dir);
        fclose(fp_main);
        fclose(fp_mae);
        fclose(fp_err);
        free(damaged);
        free(mask);
        free(out);
        series_free(&s);
        return 1;
    }

    write_csv_header(fp_main,
        "scenario,block_position,missing_rate,method,mae,rmse,r2,"
        "number_of_missing_values,number_of_evaluated_values");
    write_csv_header(fp_mae, "method,mae,scenario,block_position,missing_rate");
    write_csv_header(fp_err, "scenario,block_position,missing_rate,method,mae,rmse,r2");

    ExpRunSummary summary[EXP_NUM_SCENARIOS * EXP_NUM_RATES];
    size_t summary_count = 0;
    size_t total_method_runs = 0;

    print_experiment_intro(source, label_city, n, filter);

    for (size_t sc = 0; sc < EXP_NUM_SCENARIOS; sc++) {
        ExpScenario scenario = EXP_ALL_SCENARIOS[sc];
        if (!scenario_matches_filter(scenario, filter)) {
            continue;
        }

        for (size_t ri = 0; ri < EXP_NUM_RATES; ri++) {
            double rate = EXP_MISSING_RATES[ri];
            if (!rate_matches_filter(rate, filter)) {
                continue;
            }

            size_t removed = exp_create_damage(scenario, s.temp, n, rate, RANDOM_SEED,
                                               damaged, mask);

            size_t target_removed = (size_t)llround(rate * (double)n);
            if (removed < target_removed && removed > 0) {
                printf("  [upozorenje] Ciljano %zu uklonjenih, stvarno %zu "
                       "(rubna pravila ili velicina bloka)\n",
                       target_removed, removed);
            }

            print_run_block_header(scenario, rate, removed, n);

            exp_run_methods(&s, s.temp, damaged, mask, n, out, results);
            print_methods_table(results, EXP_NUM_METHODS);

            const char *best_name = NULL;
            double best_mae = INFINITY;
            find_best_method(results, EXP_NUM_METHODS, &best_name, &best_mae);

            if (summary_count < sizeof(summary) / sizeof(summary[0])) {
                summary[summary_count].scenario = scenario;
                summary[summary_count].rate = rate;
                summary[summary_count].removed = removed;
                summary[summary_count].best_method = best_name;
                summary[summary_count].best_mae = best_mae;
                summary[summary_count].has_best = (best_name != NULL);
                summary_count++;
            }

            for (size_t mi = 0; mi < EXP_NUM_METHODS; mi++) {
                total_method_runs++;
                if (!results[mi].ok) {
                    continue;
                }

                fprintf(fp_main, "%s,%s,%.2f,%s,%.6f,%.6f,%.6f,%zu,%zu\n",
                        exp_scenario_name(scenario),
                        exp_block_position_name(scenario),
                        rate, results[mi].name,
                        results[mi].metrics.mae, results[mi].metrics.rmse,
                        results[mi].metrics.r2, removed, results[mi].metrics.count);

                fprintf(fp_mae, "%s,%.6f,%s,%s,%.2f\n",
                        results[mi].name, results[mi].metrics.mae,
                        exp_scenario_name(scenario),
                        exp_block_position_name(scenario), rate);

                fprintf(fp_err, "%s,%s,%.2f,%s,%.6f,%.6f,%.6f\n",
                        exp_scenario_name(scenario),
                        exp_block_position_name(scenario),
                        rate, results[mi].name,
                        results[mi].metrics.mae, results[mi].metrics.rmse,
                        results[mi].metrics.r2);
            }

            if (fabs(rate - EXP_RECON_SNAPSHOT_RATE) < 1e-9) {
                export_best_worst_reconstructions(results_dir, scenario, rate,
                                                  &s, s.temp, damaged, mask, n, out,
                                                  results, EXP_NUM_METHODS);
            }
        }
    }

    fclose(fp_main);
    fclose(fp_mae);
    fclose(fp_err);

    print_experiment_footer(results_dir, main_csv, mae_csv, error_csv,
                            summary, summary_count, total_method_runs, n);

    free(damaged);
    free(mask);
    free(out);
    series_free(&s);
    return 0;
}
